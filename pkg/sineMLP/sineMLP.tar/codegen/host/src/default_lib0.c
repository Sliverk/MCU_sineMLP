#include "tvm/runtime/c_runtime_api.h"
#ifdef __cplusplus
extern "C" {
#endif
__attribute__((section(".rodata.tvm"), ))
static struct global_const_workspace {
  float fused_constant_1_let[256] __attribute__((aligned(16))); // 1024 bytes, aligned offset: 0
  float fused_nn_contrib_dense_pack_constant_1_let[16] __attribute__((packed, aligned(16))); // 64 bytes, aligned offset: 1024
  float fused_nn_contrib_dense_pack_constant_let[16] __attribute__((packed, aligned(16))); // 64 bytes, aligned offset: 1088
  float fused_constant_2_let[16] __attribute__((packed, aligned(16))); // 64 bytes, aligned offset: 1152
  float fused_constant_let[16] __attribute__((packed, aligned(16))); // 64 bytes, aligned offset: 1216
  float fused_nn_contrib_dense_pack_constant_2_let[1] __attribute__((packed, aligned(16))); // 4 bytes, aligned offset: 1280
} global_const_workspace = {
  .fused_constant_1_let = {
    -0x1.a5289p-4, -0x1.452a86p+0, 0x1.a70082p-4, 0x1.e978f6p-1, 0x1.bfadbp-6, 0x1.2ea1p-3, 0x1.6eef5ep-4, 0x1.05712ap-3, 
    -0x1.0ef578p-4, 0x1.44a31ep-1, -0x1.b1d49p-3, 0x1.8ac33cp-2, 0x1.c20788p-5, -0x1.8057e4p-3, 0x1.cbb4c8p-5, -0x1.48c194p-3, 
    -0x1.17244p-7, -0x1.df484ep-4, -0x1.e59414p-3, -0x1.58a1a6p-3, -0x1.a028cp-3, -0x1.ed60cp-5, 0x1.bad03p-6, 0x1.3a3076p-4, 
    0x1.66d2d8p-4, -0x1.c3f1e8p-3, -0x1.2177ep-3, -0x1.1c3598p-4, 0x1.08fb88p-3, 0x1.73f348p-3, -0x1.bec498p-4, -0x1.badb68p-3, 
    0x1.726ccp-7, 0x1.66194p-1, -0x1.3b4e8p-7, 0x1.6df03ep-2, -0x1.f5685cp-3, -0x1.f9435ap-3, -0x1.5c5178p-5, -0x1.12a104p-3, 
    0x1.b6e72p-6, 0x1.dd7fdp-3, -0x1.8601ap-5, 0x1.8344cp-5, 0x1.e13fcp-3, -0x1.6c345cp-3, 0x1.46964p-3, -0x1.13036p-3, 
    0x1.1f0c3p-5, 0x1.473df8p-1, -0x1.506a1ap-2, 0x1.f89b98p-7, -0x1.1b5cdp-3, 0x1.eaf4ecp-5, -0x1.cf875cp-3, 0x1.18dc0cp-5, 
    -0x1.01f9bp-3, 0x1.e6ecb8p-2, -0x1.00f1d8p-3, -0x1.3cbbe6p-2, 0x1.17cd0cp-2, 0x1.96184p-8, 0x1.16f346p-4, -0x1.c0a37p-5, 
    0x1.a9e08p-5, -0x1.8a3148p-3, -0x1.7fad18p-4, -0x1.e99134p-3, 0x1.1431cp-7, -0x1.c35c7p-4, 0x1.0e06p-10, 0x1.bd5af4p-3, 
    0x1.a9724p-4, -0x1.ea9444p-1, 0x1.787836p-4, 0x1.4d00c2p-1, -0x1.79d6acp-4, -0x1.049e8cp-3, -0x1.6317f4p-2, -0x1.5821dep-2, 
    -0x1.af270cp-3, -0x1.ef25fp-6, -0x1.a75634p-3, -0x1.16751p-1, -0x1.dd4a8cp-4, -0x1.4bcb18p-2, -0x1.2f144cp-2, -0x1.3ad6a8p-3, 
    0x1.0d391cp-3, 0x1.1fa51p-1, -0x1.bd60a4p-3, 0x1.e5aa1ap-4, -0x1.395bdep-4, -0x1.2bccbp-4, -0x1.6d4514p-3, -0x1.7936e8p-5, 
    0x1.1549e8p-3, -0x1.364e6p-5, 0x1.92bc2p-4, 0x1.4f35ap-6, -0x1.2998acp-3, 0x1.28854cp-3, -0x1.db85c4p-3, 0x1.dd0038p-4, 
    -0x1.b3e294p-3, 0x1.e333f2p-6, -0x1.0cd6f4p-2, -0x1.ef18f6p-3, -0x1.93bd42p-3, -0x1.344014p-2, 0x1.dec66ep-4, -0x1.5a848p-7, 
    0x1.37689p-5, -0x1.80203p-1, -0x1.4dceep-5, -0x1.58dc34p-6, 0x1.c3c46ep-4, -0x1.361786p-4, -0x1.b1c598p-3, -0x1.8f68f4p-3, 
    0x1.7b962p-4, 0x1.27d44p-6, -0x1.12686p-6, 0x1.6e6248p-4, 0x1.016accp-3, 0x1.3e03b4p-3, -0x1.3c7f9p-5, 0x1.a6361cp-3, 
    -0x1.d9406p-1, 0x1.ded65ep-1, -0x1.ed53a4p-3, -0x1.5e8134p-3, -0x1.a5f17p-5, 0x1.0f5f0cp-2, 0x1.1acabp-4, 0x1.7723p-3, 
    -0x1.7f2a12p-4, 0x1.02a202p-5, 0x1.0cde24p-3, -0x1.a1a54p-7, 0x1.88476p-4, -0x1.0c799p+0, -0x1.ebab4ep-4, -0x1.486d1ep+0, 
    -0x1.7e693cp-2, -0x1.1706e4p-3, 0x1.9283d4p-3, -0x1.3c16e4p-2, 0x1.134332p-3, -0x1.0bf83ep-2, -0x1.b6dap-6, -0x1.aae25ep-4, 
    0x1.bf7c1cp-3, 0x1.1a842p-5, 0x1.5863dp-4, -0x1.747a1p-4, 0x1.54419p-3, 0x1.11152p-3, 0x1.4c87fp-3, 0x1.ed76fp-3, 
    0x1.5c6e74p-1, -0x1.398482p-3, 0x1.eeceep-4, -0x1.7c0df8p-4, -0x1.475ef8p-3, -0x1.593754p+0, 0x1.39016cp-5, -0x1.0af2bap+1, 
    -0x1.81ccf4p-3, 0x1.bb621p-3, -0x1.5b4p-7, -0x1.1b42b4p-3, -0x1.b268ep-4, 0x1.60904cp-3, -0x1.a56cap-4, -0x1.fca3c8p-3, 
    0x1.bbcfb2p-6, -0x1.fe4878p-5, -0x1.965b6cp-3, -0x1.8ecef8p-5, -0x1.3e0ea6p-2, 0x1.d20f08p-3, -0x1.6550fap-1, 0x1.bec356p-3, 
    -0x1.8bf166p-4, -0x1.f15ca8p-5, -0x1.619abcp-3, -0x1.a01f0cp-3, -0x1.7a7712p-2, 0x1.4860c4p-2, -0x1.6ed794p-1, 0x1.7ec00cp-2, 
    -0x1.a3d8p-12, -0x1.8f5a78p-4, -0x1.f070b8p-3, -0x1.571a24p-3, -0x1.36ea88p-4, 0x1.dd756cp-3, 0x1.2757fcp-3, 0x1.84adp-4, 
    -0x1.eeffa6p-1, 0x1.425a9cp-6, 0x1.bdb5e8p-4, -0x1.1d7fc8p-4, 0x1.d0e79p-4, -0x1.601e18p+1, -0x1.d52e8ap-4, 0x1.ba851cp-3, 
    -0x1.f00faep-4, -0x1.5d6836p-2, -0x1.a54e94p-3, -0x1.5d12a8p-5, -0x1.40c0e4p-3, 0x1.195398p-3, 0x1.e70ea6p-4, 0x1.66de2cp-4, 
    0x1.ec0dp-4, -0x1.c60a3cp-4, -0x1.c5bfecp-3, 0x1.4d536p-4, -0x1.f2c83p-7, 0x1.e05f18p-2, -0x1.8a7facp-1, 0x1.a13b46p-2, 
    0x1.2c5fep-5, 0x1.8728c8p-3, 0x1.748488p-3, 0x1.881258p-3, 0x1.f5dfcp-4, -0x1.3b6c0cp-3, 0x1.45dc98p-3, 0x1.db0714p-3, 
    0x1.231ebep-4, -0x1.44e7b2p-2, 0x1.469488p-4, -0x1.39d152p-2, -0x1.34f53cp-2, 0x1.67e56p-3, 0x1.3f939p-4, -0x1.ed85f2p-5, 
    -0x1.edd11ep-3, -0x1.577a32p-6, 0x1.dd9e8p-7, 0x1.dd1126p-4, 0x1.b93c46p-4, 0x1.24a286p-6, 0x1.250048p-1, -0x1.ac37fcp-4, 
    0x1.c6b088p-4, -0x1.859418p-3, -0x1.de7048p-3, 0x1.aed5e8p-3, 0x1.e74dp-5, -0x1.219ed8p-4, 0x1.21b06cp-3, 0x1.3b5dbcp-3
  },
  .fused_nn_contrib_dense_pack_constant_1_let = {
    -0x1.e546a4p-3, 0x1.8ff1p-2, -0x1.16ae1p-5, -0x1.0b7528p-2, -0x1.796376p-3, -0x1.31f1c4p-5, -0x1.2861bp-5, -0x1.0a924cp-3, 
    -0x1.5b02cp-2, -0x1.0028d4p-4, -0x1.3d71p-5, -0x1.0aa98p-2, -0x1.93193cp-4, 0x1.304d52p-1, -0x1.49068ep-1, 0x1.9a2898p-2
  },
  .fused_nn_contrib_dense_pack_constant_let = {
    0x1.d93c7cp-1, 0x1.ae64b2p-1, -0x1.743dacp-1, -0x1.7ece5p-3, 0x1.972d4p+0, -0x1.2327dp-2, 0x1.1d70fp+0, 0x1.6aaa46p+0, 
    -0x1.f0d0f8p-1, 0x1.36c168p+0, 0x1.8b06dcp-3, 0x1.5b9884p+0, -0x1.1a17ep-4, 0x1.2feecp-3, -0x1.9a1a68p+0, -0x1.25b5b4p-1
  },
  .fused_constant_2_let = {
    0x1.266958p-4, 0x1.d7b638p-2, -0x1.c89248p-6, -0x1.334e6ep-2, 0x1.5d4ad2p-5, -0x1.1f8c1p-5, 0x1.5633bp-7, 0x1.ee93c2p-4, 
    0x1.1059bp-7, -0x1.7067d2p-4, 0x1.44f3dp-4, -0x1.2035d8p-5, 0x1.76b898p-4, -0x1.ca1e52p-2, 0x1.a44a8ap-1, -0x1.7ac3ccp-2
  },
  .fused_constant_let = {
    -0x1.a88546p-1, -0x1.12051ep-2, 0x1.0bc01ep-3, -0x1.3db18p-3, -0x1.8ba7f4p-2, -0x1.e2a89cp-1, -0x1.95671ap-3, -0x1.cd6702p-3, 
    -0x1.4ba238p-1, -0x1.22d458p-1, 0x1.6e379cp-4, -0x1.d5e92ep-3, -0x1.c53bdcp-1, -0x1.4fabe4p-7, 0x1.3f4464p-1, -0x1.06ca98p-1
  },
  .fused_nn_contrib_dense_pack_constant_2_let = {
    -0x1.2e966cp-2
  },
};// of total size 1284 bytes
__attribute__((section(".bss.noinit.tvm"), aligned(4)))
static uint8_t global_workspace[160];
#include <tvmgen_default.h>
TVM_DLL int32_t tvmgen_default___tvm_main__(void* input0,void* output0,uint8_t* global_const_workspace_0_var,uint8_t* global_workspace_1_var);
int32_t tvmgen_default_run(struct tvmgen_default_inputs* inputs,struct tvmgen_default_outputs* outputs) {return tvmgen_default___tvm_main__(inputs->input0,outputs->output,((uint8_t*)&global_const_workspace),((uint8_t*)&global_workspace));
}
#ifdef __cplusplus
}
#endif
;